# Orikzor — Android ilova (INN bo'yicha qidiruv)

Bu ilova yangi FastAPI backend'ga ulangan. INN terilganda shu INN'ga
bog'liq kontragent, magazinlar va to'lovlar ko'rsatiladi.

## Backend ulanishi
API manzili bitta joyda — app/src/main/java/uz/orikzor/app/ApiClient.kt:

    private const val BASE_URL = "https://merry-rejoicing-production-7ebc.up.railway.app"

Agar backend domeningiz boshqa bo'lsa, faqat shu qatorni o'zgartiring.

Ilova quyidagi ochiq endpointni chaqiradi:
    GET {BASE_URL}/api/mobile/counterparty?inn=XXX&year=2026&month=5

Javob eski PHP API bilan bir xil formatda (counterparty, shops, payments, totals).

## Ekranlar
- LoginActivity — INN kiritish + qidiruv tarixi (o'zgarmagan)
- MainActivity — kontragent, umumiy to'lovlar, xizmat turlari, magazinlar
- ShopDetailSheet — magazin detali (pastdan ochiluvchi panel)

## Ishga tushirish (Android Studio)
1. Android Studio: File -> Open -> android-project papkasi
2. Studio gradle-wrapper.jar va local.properties (SDK yo'li) ni o'zi yaratadi
3. Gradle sync -> Run

Eslatma: gradle-wrapper.jar va local.properties arxivga kiritilmagan
(mashinaga xos, Studio o'zi yaratadi).

## Texnik
- minSdk 24, targetSdk 34, Kotlin, ViewBinding
- Network: OkHttp + Gson
- INTERNET ruxsati bor; backend HTTPS (cleartext kerak emas)
