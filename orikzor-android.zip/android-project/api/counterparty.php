<?php
/**
 * COUNTERPARTY API - kontragentning to'liq ma'lumotlari
 * 
 * GET /api/v1/counterparty.php?inn=XXX&year=2026&month=5
 * 
 * Qaytaradi:
 *   - counterparty info (nomi, telefon, contract_no)
 *   - barcha magazinlar (shops[])
 *   - umumiy billing (rent + electricity + water)
 *   - har bir tur uchun jami due/paid/debt
 */

require_once __DIR__ . '/../db.php';
header('Cache-Control: no-cache, must-revalidate');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$inn = $_GET['inn'] ?? null;
if (!$inn) {
    json_error('INN parametri kerak', 400);
}

$inn = trim($inn);
$year = intval($_GET['year'] ?? date('Y'));
$month = intval($_GET['month'] ?? date('n'));

// 1. Counterparty ma'lumotlari
$counterparty = fetch_one(
    'SELECT * FROM counterparties WHERE inn = :inn',
    [':inn' => $inn]
);

if (!$counterparty) {
    json_error('INN bo\'yicha kontragent topilmadi', 404);
}

// 2. Barcha magazinlari
$shops = fetch_all(
    'SELECT shop_id, pavilion_code, region_id, monthly_rent, shop_type
     FROM shops 
     WHERE inn = :inn AND active = 1
     ORDER BY shop_id',
    [':inn' => $inn]
);

// 3. Billing (monthly_balances) - har bir tur bo'yicha
$balances = fetch_all(
    'SELECT type, SUM(debet) as debet, SUM(kredit) as kredit
     FROM monthly_balances
     WHERE inn = :inn AND year = :y AND month = :m
     GROUP BY type',
    [':inn' => $inn, ':y' => $year, ':m' => $month]
);

$rent = ['due' => 0, 'paid' => 0, 'debt' => 0];
$electricity = ['due' => 0, 'paid' => 0, 'debt' => 0];
$water = ['due' => 0, 'paid' => 0, 'debt' => 0];

foreach ($balances as $b) {
    $due = floatval($b['debet']);
    $paid = floatval($b['kredit']);
    $info = [
        'due' => $due,
        'paid' => $paid,
        'debt' => $due - $paid,
    ];
    if ($b['type'] === 'Аренда') $rent = $info;
    elseif ($b['type'] === 'Электроэнергия') $electricity = $info;
    elseif ($b['type'] === 'Вода') $water = $info;
}

// 4. Har bir magazin uchun rent_payments alohida (shop_rent_payments jadvalidan)
$shop_ids_arr = array_column($shops, 'shop_id');
$shop_payments = [];

if (!empty($shop_ids_arr)) {
    $escaped = [];
    foreach ($shop_ids_arr as $sid) {
        $escaped[] = "'" . SQLite3::escapeString($sid) . "'";
    }
    $ids_in = implode(',', $escaped);
    
    $rent_rows = fetch_all(
        "SELECT shop_id, amount_due, amount_paid, status
         FROM shop_rent_payments
         WHERE shop_id IN ($ids_in) AND year = :y AND month = :m",
        [':y' => $year, ':m' => $month]
    );
    
    foreach ($rent_rows as $r) {
        $shop_payments[$r['shop_id']] = [
            'rent_due' => floatval($r['amount_due']),
            'rent_paid' => floatval($r['amount_paid']),
            'rent_status' => $r['status'] ?: 'unknown',
        ];
    }
}

// Shop'larga payment info qo'shamiz
foreach ($shops as &$s) {
    $sid = $s['shop_id'];
    $sp = $shop_payments[$sid] ?? null;
    $s['rent_due'] = $sp['rent_due'] ?? 0;
    $s['rent_paid'] = $sp['rent_paid'] ?? 0;
    $s['rent_status'] = $sp['rent_status'] ?? 'no_data';
    $s['monthly_rent'] = floatval($s['monthly_rent']);
}
unset($s);

// 5. Umumiy statistika
$total_due = $rent['due'] + $electricity['due'] + $water['due'];
$total_paid = $rent['paid'] + $electricity['paid'] + $water['paid'];
$total_debt = max(0, $rent['debt']) + max(0, $electricity['debt']) + max(0, $water['debt']);

json_response([
    'counterparty' => [
        'inn' => $counterparty['inn'],
        'name' => $counterparty['name'],
        'contract_no' => $counterparty['contract_no'],
        'contract_date' => $counterparty['contract_date'],
        'phone' => $counterparty['phone'],
    ],
    'shops' => $shops,
    'shops_count' => count($shops),
    'period' => [
        'year' => $year,
        'month' => $month,
    ],
    'payments' => [
        'rent' => $rent,
        'electricity' => $electricity,
        'water' => $water,
    ],
    'totals' => [
        'due' => $total_due,
        'paid' => $total_paid,
        'debt' => $total_debt,
    ],
]);
