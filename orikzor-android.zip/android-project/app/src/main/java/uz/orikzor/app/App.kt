package uz.orikzor.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // Saqlangan mavzuni qo'llaymiz (light/dark/system)
        Prefs.applyTheme(Prefs.getTheme(this))
    }
}
