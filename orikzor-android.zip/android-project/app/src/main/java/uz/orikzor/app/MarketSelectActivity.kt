package uz.orikzor.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.launch
import uz.orikzor.app.databinding.ActivityMarketSelectBinding

/**
 * Birinchi ekran — bozor tanlash.
 *
 * VAQTINCHA: hozircha bozor tanlash o'tkazib yuborilgan — default "orikzor"
 * tanlanadi va to'g'ridan-to'g'ri Login (INN) ochiladi. Bozor tanlashni
 * qaytarish uchun onCreate'dagi "VAQTINCHA" blokini olib tashlang va
 * pastdagi izohga olingan kodni qayta yoqing.
 */
class MarketSelectActivity : BaseActivity() {

    private lateinit var binding: ActivityMarketSelectBinding
    private lateinit var marketManager: MarketManager
    private lateinit var adapter: MarketAdapter

    // true bo'lsa — foydalanuvchi bozorni almashtirish uchun keldi (avtomatik o'tmaymiz)
    private var changing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        marketManager = MarketManager(this)
        changing = intent.getBooleanExtra("changing", false)

        // ===== VAQTINCHA: bozor tanlashni o'tkazib yuborish =====
        if (!marketManager.hasSelection()) {
            marketManager.save("orikzor", "O'rikzor")
        }
        goToLogin()
        return
        // ===== /VAQTINCHA =====

        /* ----- Bozor tanlash mantiqi (keyinroq qaytarish uchun) -----
        binding = ActivityMarketSelectBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!changing && marketManager.hasSelection()) {
            goToLogin()
            return
        }

        adapter = MarketAdapter(emptyList()) { market ->
            marketManager.save(market.slug, market.name)
            goToLogin()
        }
        binding.recyclerMarkets.layoutManager = LinearLayoutManager(this)
        binding.recyclerMarkets.adapter = adapter

        binding.btnSettings.setOnClickListener { SettingsSheet.show(supportFragmentManager) }

        loadMarkets()
        */
    }

    /* Bozor tanlash qaytarilganda yana yoqiladi:
    private fun loadMarkets() {
        binding.progressBar.visibility = View.VISIBLE
        binding.errorContainer.visibility = View.GONE
        binding.recyclerMarkets.visibility = View.GONE

        lifecycleScope.launch {
            val result = ApiClient.getMarkets()
            binding.progressBar.visibility = View.GONE

            result.fold(
                onSuccess = { markets ->
                    if (markets.isEmpty()) {
                        binding.errorContainer.visibility = View.VISIBLE
                        binding.tvError.text = getString(R.string.markets_empty)
                    } else {
                        binding.recyclerMarkets.visibility = View.VISIBLE
                        adapter.updateData(markets)
                    }
                },
                onFailure = { err ->
                    binding.errorContainer.visibility = View.VISIBLE
                    binding.tvError.text = errMsg(err)
                }
            )
        }
    }
    */

    private fun goToLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        finish()
    }
}
