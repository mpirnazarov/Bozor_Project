package uz.orikzor.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentManager
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import uz.orikzor.app.databinding.SheetAboutBinding

/**
 * Dasturni ishlab chiqqan kompaniya (Betasoft) haqida chiroyli ma'lumot oynasi.
 * Bezovta qilmaydi — faqat foydalanuvchi o'zi bosganda ochiladi.
 */
class AboutSheet : BottomSheetDialogFragment() {

    private var _binding: SheetAboutBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = SheetAboutBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnWebsite.setOnClickListener { open("https://betasoft.uz") }
        binding.btnTelegram.setOnClickListener { open("https://t.me/betasoft_uz") }
        binding.btnPhone.setOnClickListener { open("tel:+998901234567") }
        binding.btnClose.setOnClickListener { dismiss() }
    }

    private fun open(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            // Ilova topilmasa — jim
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        fun show(fm: FragmentManager) {
            AboutSheet().show(fm, "about_betasoft")
        }
    }
}
