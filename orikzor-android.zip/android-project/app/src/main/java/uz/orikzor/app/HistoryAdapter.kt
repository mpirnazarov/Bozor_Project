package uz.orikzor.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import uz.orikzor.app.databinding.ItemHistoryBinding

class HistoryAdapter(
    private var items: List<HistoryItem>,
    private val onClick: (HistoryItem) -> Unit,
    private val onDelete: (HistoryItem) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.VH>() {
    
    class VH(val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root)
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemHistoryBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return VH(binding)
    }
    
    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val b = holder.binding
        
        b.tvHistoryInn.text = item.inn
        b.tvHistoryName.text = item.companyName.ifBlank { "—" }
        
        b.root.setOnClickListener { onClick(item) }
        b.btnDeleteHistory.setOnClickListener { onDelete(item) }
    }
    
    override fun getItemCount() = items.size
    
    fun updateData(newItems: List<HistoryItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
