package uz.orikzor.app

import com.google.gson.annotations.SerializedName

/**
 * Backend javob modellari — /api/mobile/counterparty formatiga mos.
 * (Eski PHP counterparty.php bilan bir xil struktura.)
 */

data class CounterpartyResponse(
    val counterparty: Counterparty,
    val shops: List<Shop> = emptyList(),
    @SerializedName("shops_count") val shopsCount: Int = 0,
    val period: Period? = null,
    val payments: Payments? = null,
    val totals: Totals? = null
)

data class Counterparty(
    val inn: String,
    val name: String?,
    @SerializedName("contract_no") val contractNo: String?,
    @SerializedName("contract_date") val contractDate: String?,
    val phone: String?
)

data class Shop(
    @SerializedName("shop_id") val shopId: String,
    @SerializedName("pavilion_code") val pavilionCode: String?,
    @SerializedName("region_id") val regionId: Int?,
    @SerializedName("monthly_rent") val monthlyRent: Double = 0.0,
    @SerializedName("shop_type") val shopType: String?,
    @SerializedName("rent_due") val rentDue: Double = 0.0,
    @SerializedName("rent_paid") val rentPaid: Double = 0.0,
    @SerializedName("rent_status") val rentStatus: String = "no_data"
)

data class Period(
    val year: Int,
    val month: Int
)

data class Payments(
    val rent: PaymentInfo = PaymentInfo(),
    val electricity: PaymentInfo = PaymentInfo(),
    val water: PaymentInfo = PaymentInfo()
)

data class PaymentInfo(
    val due: Double = 0.0,
    val paid: Double = 0.0,
    val debt: Double = 0.0
)

data class Totals(
    val due: Double = 0.0,
    val paid: Double = 0.0,
    val debt: Double = 0.0
)

/** Bozor (mobil ro'yxat uchun). */
data class MarketItem(
    val id: Int,
    val slug: String,
    val name: String
)

/** Mavjud davr (oy). */
data class PeriodItem(
    val year: Int,
    val month: Int
)
