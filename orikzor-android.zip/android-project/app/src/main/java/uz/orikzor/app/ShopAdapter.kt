package uz.orikzor.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import uz.orikzor.app.databinding.ItemShopBinding

class ShopAdapter(
    private var items: List<Shop>,
    private val onClick: (Shop) -> Unit
) : RecyclerView.Adapter<ShopAdapter.VH>() {

    class VH(val binding: ItemShopBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemShopBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val s = items[position]
        val b = holder.binding
        val ctx = b.root.context

        b.tvShopId.text = s.shopId
        b.tvShopType.text = s.shopType?.ifBlank { "—" } ?: "—"
        b.tvShopRent.text = MainActivity.money(ctx, s.monthlyRent)

        // Holat rangi (pill)
        val (text, colorRes, bgRes) = when (s.rentStatus) {
            "paid" -> Triple(ctx.getString(R.string.status_paid), R.color.status_paid, R.color.status_paid_bg)
            "partial" -> Triple(ctx.getString(R.string.status_partial_short), R.color.status_partial, R.color.status_partial_bg)
            "unpaid" -> Triple(ctx.getString(R.string.status_unpaid), R.color.status_unpaid, R.color.status_unpaid_bg)
            else -> Triple(ctx.getString(R.string.status_no_data), R.color.text_secondary, R.color.bg_subtle)
        }
        b.tvShopStatus.text = text
        b.tvShopStatus.setTextColor(ctx.getColor(colorRes))
        b.tvShopStatus.background = b.tvShopStatus.background?.mutate()?.apply {
            setTint(ctx.getColor(bgRes))
        }

        b.root.setOnClickListener { onClick(s) }
    }

    override fun getItemCount() = items.size

    fun updateData(newItems: List<Shop>) {
        items = newItems
        notifyDataSetChanged()
    }
}
