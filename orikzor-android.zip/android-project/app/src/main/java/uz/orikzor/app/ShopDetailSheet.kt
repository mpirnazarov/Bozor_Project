package uz.orikzor.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentManager
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.gson.Gson
import uz.orikzor.app.databinding.SheetShopDetailBinding

/**
 * Magazin detal ma'lumotlari — pastdan ochiluvchi panel (bottom sheet).
 * Arenda magazin darajasida; elektr va suv kontragent darajasida ko'rsatiladi.
 */
class ShopDetailSheet : BottomSheetDialogFragment() {

    private var _binding: SheetShopDetailBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = SheetShopDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val json = arguments?.getString(ARG_SHOP) ?: return
        val shop = Gson().fromJson(json, Shop::class.java)

        val paymentsJson = arguments?.getString(ARG_PAYMENTS)
        val payments = paymentsJson?.let { Gson().fromJson(it, Payments::class.java) }

        binding.tvShopId.text = shop.shopId
        binding.tvType.text = shop.shopType?.ifBlank { "—" } ?: "—"
        binding.tvPavilion.text = shop.pavilionCode?.ifBlank { "—" } ?: "—"
        binding.tvMonthlyRent.text = MainActivity.money(requireContext(), shop.monthlyRent)

        // ===== Arenda (magazin) =====
        binding.tvRentDue.text = MainActivity.money(requireContext(), shop.rentDue)
        binding.tvRentPaid.text = MainActivity.money(requireContext(), shop.rentPaid)

        val (text, colorRes) = when (shop.rentStatus) {
            "paid" -> getString(R.string.status_paid) to R.color.status_paid
            "partial" -> getString(R.string.status_partial) to R.color.status_partial
            "unpaid" -> getString(R.string.status_unpaid) to R.color.status_unpaid
            else -> getString(R.string.status_no_data) to R.color.text_secondary
        }
        binding.tvStatus.text = text
        binding.tvStatus.setTextColor(requireContext().getColor(colorRes))

        // ===== Elektr =====
        bindServiceBlock(binding.tvElecDue, binding.tvElecPaid, binding.tvElecDebt, payments?.electricity)
        // ===== Suv =====
        bindServiceBlock(binding.tvWaterDue, binding.tvWaterPaid, binding.tvWaterDebt, payments?.water)

        binding.btnClose.setOnClickListener { dismiss() }
    }

    private fun bindServiceBlock(
        dueView: android.widget.TextView,
        paidView: android.widget.TextView,
        debtView: android.widget.TextView,
        info: PaymentInfo?
    ) {
        dueView.text = MainActivity.money(requireContext(), info?.due ?: 0.0)
        paidView.text = MainActivity.money(requireContext(), info?.paid ?: 0.0)
        debtView.text = MainActivity.money(requireContext(), info?.debt ?: 0.0)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_SHOP = "shop_json"
        private const val ARG_PAYMENTS = "payments_json"

        fun show(fm: FragmentManager, shop: Shop, payments: Payments?) {
            val sheet = ShopDetailSheet().apply {
                arguments = Bundle().apply {
                    putString(ARG_SHOP, Gson().toJson(shop))
                    if (payments != null) putString(ARG_PAYMENTS, Gson().toJson(payments))
                }
            }
            sheet.show(fm, "shop_detail")
        }
    }
}
