package uz.orikzor.app

import android.content.Context

/**
 * Tanlangan bozorni saqlaydi (SharedPreferences).
 */
class MarketManager(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun save(slug: String, name: String) {
        prefs.edit()
            .putString(KEY_SLUG, slug)
            .putString(KEY_NAME, name)
            .apply()
    }

    fun getSlug(): String? = prefs.getString(KEY_SLUG, null)

    fun getName(): String? = prefs.getString(KEY_NAME, null)

    fun clear() {
        prefs.edit().remove(KEY_SLUG).remove(KEY_NAME).apply()
    }

    fun hasSelection(): Boolean = !getSlug().isNullOrBlank()

    companion object {
        private const val PREFS = "orikzor_market"
        private const val KEY_SLUG = "market_slug"
        private const val KEY_NAME = "market_name"
    }
}
