package uz.orikzor.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.launch
import uz.orikzor.app.databinding.ActivityLoginBinding

class LoginActivity : BaseActivity() {
    
    private lateinit var binding: ActivityLoginBinding
    private lateinit var historyManager: HistoryManager
    private lateinit var historyAdapter: HistoryAdapter
    private lateinit var marketManager: MarketManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        historyManager = HistoryManager(this)
        marketManager = MarketManager(this)

        // Bozor tanlanmagan bo'lsa — tanlash ekraniga qaytaramiz
        if (!marketManager.hasSelection()) {
            startActivity(Intent(this, MarketSelectActivity::class.java))
            finish()
            return
        }

        setupAnimations()
        setupHistory()
        setupListeners()

        // VAQTINCHA: bozor tanlash o'tkazib yuborilgani uchun market barni yashiramiz.
        // Keyinroq bozor tanlash qaytarilganda — pastdagi 2 qatorni o'chirib,
        // izohga olingan kodni qayta yoqing.
        binding.marketBar.visibility = android.view.View.GONE
        /*
        binding.tvSelectedMarket.text = marketManager.getName() ?: getString(R.string.market)
        binding.btnChangeMarket.setOnClickListener {
            val intent = Intent(this, MarketSelectActivity::class.java)
            intent.putExtra("changing", true)
            startActivity(intent)
            finish()
        }
        */

        // BetaSoft haqida (bezovta qilmaydi — faqat bosilganda)
        binding.btnAbout.setOnClickListener {
            AboutSheet.show(supportFragmentManager)
        }

        // Sozlamalar (til / mavzu)
        binding.btnSettings.setOnClickListener {
            SettingsSheet.show(supportFragmentManager)
        }

        // Tarixni yuklash
        refreshHistory()
    }
    
    private fun setupAnimations() {
        binding.logoContainer.alpha = 0f
        binding.loginCard.alpha = 0f
        binding.loginCard.translationY = 100f
        
        binding.logoContainer.animate()
            .alpha(1f)
            .setDuration(600)
            .start()
        
        binding.loginCard.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(700)
            .setStartDelay(200)
            .start()
    }
    
    private fun setupHistory() {
        historyAdapter = HistoryAdapter(
            items = emptyList(),
            onClick = { item ->
                // Tarix elementini bosgan - INN ni input ga qo'yib login qilish
                binding.editInn.setText(item.inn)
                binding.editInn.setSelection(item.inn.length)
                checkInn(item.inn)
            },
            onDelete = { item ->
                // X tugma - faqat ushbu elementni o'chirish
                historyManager.remove(item.inn)
                refreshHistory()
            }
        )
        
        binding.recyclerHistory.layoutManager = LinearLayoutManager(this)
        binding.recyclerHistory.adapter = historyAdapter
    }
    
    private fun setupListeners() {
        binding.btnLogin.setOnClickListener {
            val inn = binding.editInn.text.toString().trim()
            
            if (inn.isEmpty()) {
                binding.tilInn.error = getString(R.string.error_inn_empty)
                return@setOnClickListener
            }
            
            if (inn.length < 9) {
                binding.tilInn.error = getString(R.string.error_inn_short)
                return@setOnClickListener
            }
            
            binding.tilInn.error = null
            checkInn(inn)
        }
        
        binding.editInn.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                binding.btnLogin.performClick()
                true
            } else false
        }
        
        binding.btnClearHistory.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.clear_history_title))
                .setMessage(getString(R.string.clear_history_msg))
                .setPositiveButton(getString(R.string.clear_history_yes)) { _, _ ->
                    historyManager.clear()
                    refreshHistory()
                }
                .setNegativeButton(getString(R.string.cancel), null)
                .show()
        }
    }
    
    private fun refreshHistory() {
        val items = historyManager.getHistory()
        historyAdapter.updateData(items)
        binding.historySection.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
    }
    
    private fun checkInn(inn: String) {
        binding.btnLogin.isEnabled = false
        binding.btnLogin.text = getString(R.string.checking)
        binding.progressBar.visibility = View.VISIBLE
        binding.errorContainer.visibility = View.GONE
        
        lifecycleScope.launch {
            val marketSlug = marketManager.getSlug() ?: ""
            val result = ApiClient.getCounterpartyByInn(inn, marketSlug)
            
            binding.btnLogin.isEnabled = true
            binding.btnLogin.text = getString(R.string.continue_btn)
            binding.progressBar.visibility = View.GONE
            
            result.fold(
                onSuccess = { response ->
                    // Muvaffaqiyatli - tarixga qo'shish
                    val companyName = response.counterparty.name ?: getString(R.string.counterparty)
                    historyManager.addOrUpdate(inn, companyName)
                    
                    val intent = Intent(this@LoginActivity, MainActivity::class.java)
                    intent.putExtra("inn", inn)
                    intent.putExtra("counterparty_name", companyName)
                    startActivity(intent)
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
                },
                onFailure = { err ->
                    binding.errorContainer.visibility = View.VISIBLE
                    binding.tvError.text = errMsg(err)
                }
            )
        }
    }
    
    override fun onResume() {
        super.onResume()
        // Boshqa Activity'dan qaytganda tarixni yangilash
        refreshHistory()
    }
}
