package uz.orikzor.app

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * API ulanish — YANGI backend (FastAPI).
 *
 * Eski PHP: https://orikzor.betasoft.uz/api/v1/counterparty.php?inn=...
 * Yangi:    {BASE_URL}/api/mobile/counterparty?inn=...&year=...&month=...
 *
 * Javob formati eski PHP bilan bir xil — shuning uchun ilova kodi o'zgarmaydi.
 */
/** Lokalizatsiya qilinadigan xato — resId orqali UI tilga o'giradi. */
class ApiException(val resId: Int) : Exception()

object ApiClient {

    // ⚙️ Yangi backend manzili. Productionда haqiqiy domeningizga almashtiring.
    // Railway backend: https://merry-rejoicing-production-7ebc.up.railway.app
    private const val BASE_URL = "https://merry-rejoicing-production-7ebc.up.railway.app"

    private val gson = Gson()

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    /**
     * Bozorlar ro'yxati (faol).
     */
    suspend fun getMarkets(): Result<List<MarketItem>> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$BASE_URL/api/mobile/markets")
                .get()
                .build()
            client.newCall(request).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val type = object : TypeToken<List<MarketItem>>() {}.type
                    val list: List<MarketItem> = gson.fromJson(body, type) ?: emptyList()
                    Result.success(list)
                } else {
                    Result.failure(ApiException(R.string.error_server))
                }
            }
        } catch (e: Exception) {
            Result.failure(ApiException(R.string.error_network))
        }
    }

    /**
     * Shu INN uchun DB'da mavjud oylar (eng so'nggi 12 ta).
     */
    suspend fun getPeriods(inn: String, market: String): Result<List<PeriodItem>> =
        withContext(Dispatchers.IO) {
            try {
                val url = "$BASE_URL/api/mobile/periods?inn=" +
                    URLEncoder.encode(inn.trim(), "UTF-8") +
                    "&market=" + URLEncoder.encode(market, "UTF-8")
                val request = Request.Builder().url(url).get().build()
                client.newCall(request).execute().use { resp ->
                    val body = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) {
                        val type = object : TypeToken<List<PeriodItem>>() {}.type
                        val list: List<PeriodItem> = gson.fromJson(body, type) ?: emptyList()
                        Result.success(list)
                    } else {
                        Result.failure(ApiException(R.string.error_server))
                    }
                }
            } catch (e: Exception) {
                Result.failure(ApiException(R.string.error_network))
            }
        }

    /**
     * INN bo'yicha kontragent + magazinlar + to'lovlarni qaytaradi.
     * market — tanlangan bozor slug (majburiy). Faqat shu bozordan qidiradi.
     */
    suspend fun getCounterpartyByInn(
        inn: String,
        market: String,
        year: Int? = null,
        month: Int? = null
    ): Result<CounterpartyResponse> = withContext(Dispatchers.IO) {
        try {
            val sb = StringBuilder("$BASE_URL/api/mobile/counterparty?inn=")
            sb.append(URLEncoder.encode(inn.trim(), "UTF-8"))
            sb.append("&market=").append(URLEncoder.encode(market, "UTF-8"))
            if (year != null) sb.append("&year=").append(year)
            if (month != null) sb.append("&month=").append(month)

            val request = Request.Builder()
                .url(sb.toString())
                .get()
                .build()

            client.newCall(request).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                when {
                    resp.isSuccessful -> {
                        val parsed = gson.fromJson(body, CounterpartyResponse::class.java)
                        if (parsed?.counterparty != null) {
                            Result.success(parsed)
                        } else {
                            Result.failure(ApiException(R.string.error_server))
                        }
                    }
                    resp.code == 404 -> Result.failure(ApiException(R.string.error_inn_not_found))
                    else -> Result.failure(ApiException(R.string.error_server))
                }
            }
        } catch (e: Exception) {
            Result.failure(ApiException(R.string.error_network))
        }
    }
}
