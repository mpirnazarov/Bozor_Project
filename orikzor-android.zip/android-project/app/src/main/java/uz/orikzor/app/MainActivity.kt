package uz.orikzor.app

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.View
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.launch
import uz.orikzor.app.databinding.ActivityMainBinding
import java.text.DecimalFormat

class MainActivity : BaseActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var shopAdapter: ShopAdapter

    private var inn: String = ""
    private var lastPayments: Payments? = null

    // Tanlangan davr. null = avtomatik (eng so'nggi mavjud oy).
    private var selectedYear: Int? = null
    private var selectedMonth: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        inn = intent.getStringExtra("inn").orEmpty()
        val name = intent.getStringExtra("counterparty_name").orEmpty()

        binding.tvCompanyName.text = name.ifBlank { getString(R.string.counterparty) }
        binding.tvInn.text = "INN: $inn"

        binding.btnBack.setOnClickListener {
            finish()
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
        }

        binding.periodBar.setOnClickListener { showPeriodPicker() }
        updatePeriodLabel()

        binding.btnAbout.setOnClickListener { AboutSheet.show(supportFragmentManager) }

        // Logo/info toggle: default i-tugma -> bosilganda logo -> yana bosilganda i
        binding.btnLogoToggle.setOnClickListener {
            val showingLogo = binding.imgLogo.visibility == View.VISIBLE
            if (showingLogo) {
                binding.imgLogo.visibility = View.GONE
                binding.imgInfo.visibility = View.VISIBLE
            } else {
                binding.imgInfo.visibility = View.GONE
                binding.imgLogo.visibility = View.VISIBLE
            }
        }

        shopAdapter = ShopAdapter(emptyList()) { shop ->
            ShopDetailSheet.show(supportFragmentManager, shop, lastPayments)
        }
        binding.recyclerShops.layoutManager = LinearLayoutManager(this)
        binding.recyclerShops.adapter = shopAdapter

        loadData()
    }

    private fun updatePeriodLabel() {
        val y = selectedYear
        val m = selectedMonth
        binding.tvPeriod.text = if (y != null && m != null) {
            "${monthName(this, m)} $y"
        } else {
            getString(R.string.period_auto)
        }
    }

    private fun showPeriodPicker() {
        val marketSlug = MarketManager(this).getSlug() ?: ""
        lifecycleScope.launch {
            val result = ApiClient.getPeriods(inn, marketSlug)
            result.fold(
                onSuccess = { periods ->
                    if (periods.isEmpty()) {
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle(getString(R.string.period))
                            .setMessage(getString(R.string.no_periods))
                            .setPositiveButton(getString(R.string.ok), null)
                            .show()
                        return@fold
                    }
                    val labels = arrayOf(getString(R.string.period_auto_full)) +
                        periods.map { "${monthName(this@MainActivity, it.month)} ${it.year}" }.toTypedArray()
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(getString(R.string.select_month))
                        .setItems(labels) { _, which ->
                            if (which == 0) {
                                selectedYear = null
                                selectedMonth = null
                            } else {
                                val p = periods[which - 1]
                                selectedYear = p.year
                                selectedMonth = p.month
                            }
                            updatePeriodLabel()
                            loadData()
                        }
                        .show()
                },
                onFailure = {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(getString(R.string.error_server))
                        .setMessage(errMsg(it, R.string.periods_load_error))
                        .setPositiveButton(getString(R.string.ok), null)
                        .show()
                }
            )
        }
    }

    private fun loadData() {
        binding.progressBar.visibility = View.VISIBLE
        binding.contentContainer.visibility = View.GONE
        binding.errorContainer.visibility = View.GONE

        lifecycleScope.launch {
            val marketSlug = MarketManager(this@MainActivity).getSlug() ?: ""
            val result = ApiClient.getCounterpartyByInn(inn, marketSlug, selectedYear, selectedMonth)
            binding.progressBar.visibility = View.GONE

            result.fold(
                onSuccess = { resp -> bindData(resp) },
                onFailure = { err ->
                    binding.errorContainer.visibility = View.VISIBLE
                    binding.tvError.text = errMsg(err)
                }
            )
        }
    }

    private fun bindData(resp: CounterpartyResponse) {
        binding.contentContainer.visibility = View.VISIBLE

        binding.tvCompanyName.text = resp.counterparty.name ?: getString(R.string.counterparty)
        binding.tvInn.text = "INN: ${resp.counterparty.inn}"

        val phone = resp.counterparty.phone
        if (!phone.isNullOrBlank()) {
            binding.tvPhone.visibility = View.VISIBLE
            binding.tvPhone.text = getString(R.string.phone_prefix, phone)
        } else {
            binding.tvPhone.visibility = View.GONE
        }
        val contract = resp.counterparty.contractNo
        if (!contract.isNullOrBlank()) {
            binding.tvContract.visibility = View.VISIBLE
            binding.tvContract.text = getString(R.string.contract_prefix, contract)
        } else {
            binding.tvContract.visibility = View.GONE
        }

        val totals = resp.totals
        binding.tvTotalDue.text = money(this, totals?.due ?: 0.0)
        binding.tvTotalPaid.text = money(this, totals?.paid ?: 0.0)
        binding.tvTotalDebt.text = money(this, totals?.debt ?: 0.0)

        val p = resp.payments
        lastPayments = p
        bindServiceRow(
            binding.rowRent.root, getString(R.string.service_rent),
            p?.rent?.due ?: 0.0, p?.rent?.paid ?: 0.0, p?.rent?.debt ?: 0.0
        )
        bindServiceRow(
            binding.rowElectricity.root, getString(R.string.service_electricity),
            p?.electricity?.due ?: 0.0, p?.electricity?.paid ?: 0.0, p?.electricity?.debt ?: 0.0
        )
        bindServiceRow(
            binding.rowWater.root, getString(R.string.service_water),
            p?.water?.due ?: 0.0, p?.water?.paid ?: 0.0, p?.water?.debt ?: 0.0
        )

        binding.tvShopsCount.text = getString(R.string.shops_count, resp.shopsCount)
        shopAdapter.updateData(resp.shops)

        val per = resp.period
        if (per != null && per.month in 1..12) {
            binding.tvPeriod.text = "${monthName(this, per.month)} ${per.year}"
        }
    }

    private fun bindServiceRow(row: View, label: String, due: Double, paid: Double, debt: Double) {
        row.findViewById<android.widget.TextView>(R.id.tvServiceName).text = label
        row.findViewById<android.widget.TextView>(R.id.tvServiceDue).text = money(this, due)
        row.findViewById<android.widget.TextView>(R.id.tvServicePaid).text = money(this, paid)
        row.findViewById<android.widget.TextView>(R.id.tvServiceDebt).text = money(this, debt)
    }

    companion object {
        private val fmt = DecimalFormat("#,###")

        /** Oy nomini joriy tilda qaytaradi (1..12). */
        fun monthName(ctx: Context, month: Int): String {
            val id = ctx.resources.getIdentifier("month_$month", "string", ctx.packageName)
            return if (id != 0) ctx.getString(id) else month.toString()
        }

        fun money(ctx: Context, v: Double): String {
            val s = fmt.format(v).replace(",", " ")
            return "$s ${ctx.getString(R.string.money_suffix)}"
        }
    }
}
