package uz.orikzor.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentManager
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import uz.orikzor.app.databinding.SheetSettingsBinding

/**
 * Til va mavzu tanlash oynasi. Tanlangach ekran qayta yaratiladi (recreate).
 */
class SettingsSheet : BottomSheetDialogFragment() {

    private var _binding: SheetSettingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = SheetSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ctx = requireContext()

        // Joriy til tanlanganini belgilash
        when (Prefs.getLang(ctx)) {
            "uz" -> binding.langUz.isChecked = true
            "ru" -> binding.langRu.isChecked = true
            "en" -> binding.langEn.isChecked = true
        }
        when (Prefs.getTheme(ctx)) {
            Prefs.THEME_LIGHT -> binding.themeLight.isChecked = true
            Prefs.THEME_DARK -> binding.themeDark.isChecked = true
            else -> binding.themeSystem.isChecked = true
        }

        binding.langGroup.setOnCheckedChangeListener { _, id ->
            val lang = when (id) {
                R.id.langRu -> "ru"
                R.id.langEn -> "en"
                else -> "uz"
            }
            if (lang != Prefs.getLang(ctx)) {
                Prefs.setLang(ctx, lang)
                recreateHost()
            }
        }

        binding.themeGroup.setOnCheckedChangeListener { _, id ->
            val theme = when (id) {
                R.id.themeLight -> Prefs.THEME_LIGHT
                R.id.themeDark -> Prefs.THEME_DARK
                else -> Prefs.THEME_SYSTEM
            }
            if (theme != Prefs.getTheme(ctx)) {
                Prefs.setTheme(ctx, theme)
                recreateHost()
            }
        }

        binding.btnClose.setOnClickListener { dismiss() }
    }

    private fun recreateHost() {
        dismiss()
        activity?.recreate()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        fun show(fm: FragmentManager) {
            SettingsSheet().show(fm, "settings")
        }
    }
}
