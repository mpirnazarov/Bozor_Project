package uz.orikzor.app

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class HistoryItem(
    val inn: String,
    val companyName: String,
    val lastUsedAt: Long = System.currentTimeMillis()
)

class HistoryManager(context: Context) {
    
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()
    
    companion object {
        private const val PREFS_NAME = "orikzor_history"
        private const val KEY_HISTORY = "inn_history"
        private const val MAX_ITEMS = 10  // oxirgi 10 ta INN
    }
    
    /**
     * Barcha tarix elementlarini olish (oxirgi ishlatilgani birinchi)
     */
    fun getHistory(): List<HistoryItem> {
        val json = prefs.getString(KEY_HISTORY, null) ?: return emptyList()
        return try {
            val type = object : TypeToken<List<HistoryItem>>() {}.type
            val list: List<HistoryItem> = gson.fromJson(json, type) ?: emptyList()
            list.sortedByDescending { it.lastUsedAt }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    /**
     * Yangi INN qo'shish yoki mavjudini yangilash
     */
    fun addOrUpdate(inn: String, companyName: String) {
        if (inn.isBlank()) return
        
        val current = getHistory().toMutableList()
        
        // Mavjud INN ni o'chirib qaytadan qo'shamiz (yangi vaqt bilan)
        current.removeAll { it.inn == inn }
        current.add(0, HistoryItem(inn, companyName, System.currentTimeMillis()))
        
        // Faqat oxirgi MAX_ITEMS ta
        val trimmed = current.take(MAX_ITEMS)
        
        saveAll(trimmed)
    }
    
    /**
     * Bitta INN ni o'chirish
     */
    fun remove(inn: String) {
        val current = getHistory().toMutableList()
        current.removeAll { it.inn == inn }
        saveAll(current)
    }
    
    /**
     * Hammasini tozalash
     */
    fun clear() {
        prefs.edit().remove(KEY_HISTORY).apply()
    }
    
    private fun saveAll(items: List<HistoryItem>) {
        val json = gson.toJson(items)
        prefs.edit().putString(KEY_HISTORY, json).apply()
    }
}
