package uz.orikzor.app

import android.content.Context
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity

/**
 * Barcha ekranlar uchun asos — saqlangan tilni qo'llaydi.
 */
open class BaseActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Prefs.wrapLocale(newBase))
    }

    /** Xatoni joriy tilga o'giradi (ApiException bo'lsa resId orqali). */
    protected fun errMsg(e: Throwable, @StringRes fallback: Int = R.string.error_unknown): String {
        return when (e) {
            is ApiException -> getString(e.resId)
            else -> e.message ?: getString(fallback)
        }
    }
}
