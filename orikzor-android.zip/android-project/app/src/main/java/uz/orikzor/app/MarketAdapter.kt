package uz.orikzor.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import uz.orikzor.app.databinding.ItemMarketBinding

class MarketAdapter(
    private var items: List<MarketItem>,
    private val onClick: (MarketItem) -> Unit
) : RecyclerView.Adapter<MarketAdapter.VH>() {

    class VH(val binding: ItemMarketBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemMarketBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        holder.binding.tvMarketName.text = m.name
        holder.binding.root.setOnClickListener { onClick(m) }
    }

    override fun getItemCount() = items.size

    fun updateData(newItems: List<MarketItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
